Azure Page Link: https://comp2084app-c4fgc2e4g9d3cugs.canadacentral-01.azurewebsites.net/

The Budget Sorting Application, or Budgetting App for short, is an application designed to take input from an user regarding the Budget they take, and using a database help the user Budget their expense so they don't overspend or fall into debt.
Conceptually speaking, the program is quite simple to use, making it so it's friendly and doesn't require too much nuance to set up, with the intent of keeping the user's workload at a minimum.

The program uses a basic template, but tweaked around simplicity, keeping colour contrast high enough for readability while using darker colours to help with a person's eyesight, with a different font from default to further improve readability.

We have used MVC Build. 
(INSERT MVC BUILD INFO HERE)

SQL DATABASE
(INSERT DIAGRAMS INTO READ.ME AS WELL)

(REFERENCE PAGE MAYBE? I THINK THAT COULD BE COOL)
